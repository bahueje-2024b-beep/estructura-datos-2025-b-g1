import java.util.*;

public class GrafoCiudades {
    // Estructura principal: Mapa de ciudad -> lista de ciudades conectadas
    private Map<String, List<String>> grafo = new HashMap<>();

    // Agregar una ciudad al grafo
    public void agregarCiudad(String ciudad) {
        grafo.putIfAbsent(ciudad, new ArrayList<>());
    }

    // Agregar una ruta bidireccional entre ciudades
    public void agregarRuta(String origen, String destino) {
        grafo.get(origen).add(destino);
        grafo.get(destino).add(origen);
    }

    // Recorrido BFS (anchura) desde una ciudad inicial
    public void bfs(String inicio) {
        Set<String> visitados = new HashSet<>(); // Para evitar visitar dos veces
        Queue<String> cola = new LinkedList<>(); // Cola FIFO para recorrer niveles
        cola.add(inicio);
        visitados.add(inicio);

        while (!cola.isEmpty()) {
            String ciudad = cola.poll(); // Extrae el primer elemento
            System.out.println("Visitando: " + ciudad);

            // Recorre todas las ciudades vecinas
            for (String vecino : grafo.get(ciudad)) {
                if (!visitados.contains(vecino)) {
                    visitados.add(vecino);
                    cola.add(vecino);
                }
            }
        }
    }

    public static void main(String[] args) {
        GrafoCiudades mapa = new GrafoCiudades();

        // Crear las ciudades
        mapa.agregarCiudad("A");
        mapa.agregarCiudad("B");
        mapa.agregarCiudad("C");
        mapa.agregarCiudad("D");

        // Agregar rutas entre ellas
        mapa.agregarRuta("A", "B");
        mapa.agregarRuta("A", "C");
        mapa.agregarRuta("B", "D");

        // Recorrer desde la ciudad A
        mapa.bfs("A");
    }
}
