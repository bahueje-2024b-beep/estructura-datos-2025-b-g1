class BST {
    Nodo raiz; // Nodo raíz del árbol

    // Método para insertar un nuevo valor
    Nodo insertar(Nodo nodo, int valor) {
        if (nodo == null) return new Nodo(valor); // Crear nuevo nodo si está vacío
        if (valor < nodo.valor)
            nodo.izq = insertar(nodo.izq, valor); // Insertar en subárbol izquierdo
        else if (valor > nodo.valor)
            nodo.der = insertar(nodo.der, valor); // Insertar en subárbol derecho
        return nodo; // Retornar el nodo actual (sin cambios)
    }

    // Método para buscar un valor
    boolean buscar(Nodo nodo, int valor) {
        if (nodo == null) return false; // Árbol vacío
        if (valor == nodo.valor) return true; // Valor encontrado
        // Buscar recursivamente en la rama adecuada
        return valor < nodo.valor ? buscar(nodo.izq, valor) : buscar(nodo.der, valor);
    }

    public static void main(String[] args) {
        BST arbol = new BST();

        // Insertar nodos en el BST
        arbol.raiz = arbol.insertar(arbol.raiz, 50);
        arbol.insertar(arbol.raiz, 30);
        arbol.insertar(arbol.raiz, 70);
        arbol.insertar(arbol.raiz, 20);
        arbol.insertar(arbol.raiz, 40);

        // Buscar valores
        System.out.println("¿Existe 30? " + arbol.buscar(arbol.raiz, 30)); // true
        System.out.println("¿Existe 90? " + arbol.buscar(arbol.raiz, 90)); // false
    }
}

