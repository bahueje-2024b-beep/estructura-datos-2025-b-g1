public class AnalisisComplejidad {
    public static void main(String[] args) {
        System.out.println("ANÁLISIS DE COMPLEJIDAD");
        System.out.println("--------------------------------------");
        System.out.println("Pila (Push/Pop): O(1)");
        System.out.println("Cola (Enqueue/Dequeue): O(1)");
        System.out.println("HashMap (Insertar/Buscar): O(1) promedio");
        System.out.println("Árbol Binario (Recorridos): O(n)");
        System.out.println("AVL (Inserción/Rotación): O(log n)");
        System.out.println("BST (Buscar/Insertar): O(log n) promedio");
        System.out.println("Grafo (BFS/Dijkstra): O(V + E)");
    }
}


