class NodoAVL {
    int valor, altura;
    NodoAVL izq, der;

    NodoAVL(int valor) {
        this.valor = valor;
        altura = 1;
    }
}

public class ArbolAVL {
    NodoAVL raiz;

    int altura(NodoAVL n) {
        return n == null ? 0 : n.altura;
    }

    int balance(NodoAVL n) {
        return (n == null) ? 0 : altura(n.izq) - altura(n.der);
    }

    NodoAVL rotacionDerecha(NodoAVL y) {
        NodoAVL x = y.izq;
        NodoAVL T2 = x.der;

        x.der = y;
        y.izq = T2;

        y.altura = Math.max(altura(y.izq), altura(y.der)) + 1;
        x.altura = Math.max(altura(x.izq), altura(x.der)) + 1;

        return x;
    }

    NodoAVL rotacionIzquierda(NodoAVL x) {
        NodoAVL y = x.der;
        NodoAVL T2 = y.izq;

        y.izq = x;
        x.der = T2;

        x.altura = Math.max(altura(x.izq), altura(x.der)) + 1;
        y.altura = Math.max(altura(y.izq), altura(y.der)) + 1;

        return y;
    }

    NodoAVL insertar(NodoAVL nodo, int valor) {
        if (nodo == null) return new NodoAVL(valor);

        if (valor < nodo.valor)
            nodo.izq = insertar(nodo.izq, valor);
        else if (valor > nodo.valor)
            nodo.der = insertar(nodo.der, valor);
        else
            return nodo; // duplicado no permitido

        nodo.altura = 1 + Math.max(altura(nodo.izq), altura(nodo.der));

        int balance = balance(nodo);

        // Rotaciones
        if (balance > 1 && valor < nodo.izq.valor) {
            System.out.println("Rotación simple derecha en " + nodo.valor);
            return rotacionDerecha(nodo);
        }
        if (balance < -1 && valor > nodo.der.valor) {
            System.out.println("Rotación simple izquierda en " + nodo.valor);
            return rotacionIzquierda(nodo);
        }
        if (balance > 1 && valor > nodo.izq.valor) {
            System.out.println("Rotación doble izquierda-derecha en " + nodo.valor);
            nodo.izq = rotacionIzquierda(nodo.izq);
            return rotacionDerecha(nodo);
        }
        if (balance < -1 && valor < nodo.der.valor) {
            System.out.println("Rotación doble derecha-izquierda en " + nodo.valor);
            nodo.der = rotacionDerecha(nodo.der);
            return rotacionIzquierda(nodo);
        }

        return nodo;
    }

    void preorden(NodoAVL nodo) {
        if (nodo != null) {
            System.out.print(nodo.valor + " ");
            preorden(nodo.izq);
            preorden(nodo.der);
        }
    }

    public static void main(String[] args) {
        ArbolAVL arbol = new ArbolAVL();
        int[] valores = {10, 20, 30, 40, 50, 25};
        for (int v : valores)
            arbol.raiz = arbol.insertar(arbol.raiz, v);

        System.out.print("\nRecorrido preorden del árbol balanceado: ");
        arbol.preorden(arbol.raiz);
    }
}

