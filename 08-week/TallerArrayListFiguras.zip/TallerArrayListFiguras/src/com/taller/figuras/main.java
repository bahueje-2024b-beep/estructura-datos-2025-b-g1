package com.taller.figuras;

import java.util.ArrayList;

public class main {
    public static void main(String[] args) {
        ArrayList<Object> figuras = new ArrayList<>();

        // Agregar 2 círculos
        figuras.add(new Circulo(5, "Rojo"));
        figuras.add(new Circulo(3.5, "Azul"));

        // Agregar 2 rectángulos
        figuras.add(new Rectangulo(4, 6, "Verde"));
        figuras.add(new Rectangulo(2.5, 3.5, "Amarillo"));

        // Agregar 2 triángulos
        figuras.add(new Triangulo(3, 4, 5, "Naranja"));
        figuras.add(new Triangulo(6, 6, 6, "Morado"));

        // Recorrer e imprimir
        System.out.println("=== LISTA DE FIGURAS ===");
        for (Object figura : figuras) {
            if (figura instanceof Circulo) {
                ((Circulo) figura).mostrarInformacion();
            } else if (figura instanceof Rectangulo) {
                ((Rectangulo) figura).mostrarInformacion();
            } else if (figura instanceof Triangulo) {
                ((Triangulo) figura).mostrarInformacion();
            }
        }
    }
}

