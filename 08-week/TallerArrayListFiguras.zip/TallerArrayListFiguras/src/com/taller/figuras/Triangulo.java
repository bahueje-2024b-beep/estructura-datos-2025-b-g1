package com.taller.figuras;

public class Triangulo {
    private double lado1;
    private double lado2;
    private double lado3;
    private String color;

    public Triangulo(double lado1, double lado2, double lado3, String color) {
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
        this.color = color;
    }

    public double calcularArea() {
        double s = (lado1 + lado2 + lado3) / 2.0;
        return Math.sqrt(s * (s - lado1) * (s - lado2) * (s - lado3));
    }

    public double calcularPerimetro() {
        return lado1 + lado2 + lado3;
    }

    public void mostrarInformacion() {
        System.out.printf("Triángulo - Lados: %.2f, %.2f, %.2f, Color: %s, Área: %.2f, Perímetro: %.2f%n",
                lado1, lado2, lado3, color, calcularArea(), calcularPerimetro());
    }
}

