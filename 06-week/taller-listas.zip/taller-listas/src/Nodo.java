/**
 * Autor: Brayan Andres Hueje Cubillos
 * Fecha: 08/09/2025
 * Versión: 1.0
 * Descripción: Clase Nodo utilizada para la implementación de listas enlazadas.
 */
public class Nodo {
    int dato;
    Nodo siguiente;

    public Nodo(int dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}
