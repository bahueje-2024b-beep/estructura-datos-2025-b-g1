/**
 * Autor: Brayan Andres Hueje Cubillos
 * Fecha: 08/09/2025
 * Versión: 1.0
 * Descripción: Prueba de inserción y eliminación en una lista doblemente enlazada.
 */
public class Ejercicio4 {
    public static void main(String[] args) {
        ListaDoble lista = new ListaDoble();

        System.out.println("Insertando al inicio:");
        lista.insertarInicio(10);
        lista.insertarInicio(20);
        lista.mostrar();

        System.out.println("Insertando al final:");
        lista.insertarFinal(30);
        lista.insertarFinal(40);
        lista.mostrar();

        System.out.println("Eliminando del inicio:");
        lista.eliminarInicio();
        lista.mostrar();

        System.out.println("Eliminando del final:");
        lista.eliminarFinal();
        lista.mostrar();
    }
}