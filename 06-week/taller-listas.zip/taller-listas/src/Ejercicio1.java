/**
 * Autor: Brayan Andres Hueje Cubillos
 * Fecha: 08/09/2025
 * Versión: 1.0
 * Descripción: Prueba de inserción de elementos al final de una lista simple.
 */
public class Ejercicio1 {
    public static void main(String[] args) {
        ListaSimple lista = new ListaSimple();
        lista.insertarFinal(1);
        lista.insertarFinal(2);
        lista.insertarFinal(3);
        System.out.println("Lista después de insertar al final:");
        lista.mostrar();
    }
}