/**
 * Autor: Brayan Andres Hueje Cubillos
 * Fecha: 08/09/2025
 * Versión: 1.0
 * Descripción: Prueba de inserción de elementos en posiciones específicas de una lista simple.
 */
public class Ejercicio2 {
    public static void main(String[] args) {
        ListaSimple lista = new ListaSimple();
        lista.insertarFinal(1);
        lista.insertarFinal(3);
        lista.insertarPosicion(2, 2); // Insertar 2 en posición 2
        lista.insertarPosicion(0, 1); // Insertar 0 al inicio
        System.out.println("Lista después de inserciones en posiciones específicas:");
        lista.mostrar();
    }
}
