/**
 * Autor: Brayan Andres Hueje Cubillos
 * Fecha: 08/09/2025
 * Versión: 1.0
 * Descripción: Prueba de inserción y eliminación en una lista circular.
 */
public class Ejercicio5 {
    public static void main(String[] args) {
        ListaCircular lista = new ListaCircular();

        System.out.println("Insertando al final:");
        lista.insertarFinal(1);
        lista.insertarFinal(2);
        lista.insertarFinal(3);
        lista.mostrar();

        System.out.println("Insertando en posición 2:");
        lista.insertarPosicion(99, 2);
        lista.mostrar();

        System.out.println("Eliminando posición 3:");
        lista.eliminarPosicion(3);
        lista.mostrar();
    }
}