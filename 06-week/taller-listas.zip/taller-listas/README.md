# Taller - Implementación de listas (Unidad 2)

**Autor:** Brayan Andres Hueje Cubillos  
**Fecha:** 08/09/2025  
**Materia:** Estructura de Datos

## 📌 Descripción
Este proyecto implementa diferentes tipos de listas enlazadas en Java:
- Lista simple
- Lista doblemente enlazada
- Lista circular

Cada lista se prueba con ejercicios específicos (Ejercicio1 a Ejercicio6), donde se validan las operaciones de inserción y eliminación.

## 📂 Contenido
- **src/** → Código fuente (`Nodo.java`, `ListaSimple.java`, `ListaDoble.java`, `ListaCircular.java`, `Ejercicio1..6.java`)
- **evidencias/** → Capturas de pantalla de la ejecución de cada ejercicio
- **README.md** → Descripción general del proyecto
- **COMPLEJIDAD.md** → Tabla de análisis de complejidad

## 📌 Ejercicios
- **Ejercicio 1:** Lista básica con inserción al final.
- **Ejercicio 2:** Inserción en posiciones específicas.
- **Ejercicio 3:** Eliminación en posiciones específicas (con control de errores).
- **Ejercicio 4:** Lista doble con inserción y eliminación en ambos extremos.
- **Ejercicio 5:** Lista circular con inserción y eliminación en posiciones.
- **Ejercicio 6:** Simulación de lista de espera en un consultorio médico.

## ✅ Conclusiones
- Las listas enlazadas permiten una gestión flexible de nodos en memoria dinámica.
- Se comprobó el funcionamiento de inserción y eliminación en listas simples, dobles y circulares.
- El análisis de complejidad muestra las diferencias de eficiencia entre cada tipo de lista.
