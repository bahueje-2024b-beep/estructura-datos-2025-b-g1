# Análisis de complejidad

## 📌 Tabla comparativa

| Operación           | Lista simple | Lista doble (con puntero a último) |
|---------------------|--------------|------------------------------------|
| Insertar inicio     | O(1)         | O(1)                               |
| Insertar fin        | O(n)         | O(1)                               |
| Insertar posición   | O(n)         | O(n)                               |
| Eliminar inicio     | O(1)         | O(1)                               |
| Eliminar fin        | O(n)         | O(1)                               |
| Eliminar posición   | O(n)         | O(n)                               |

## 📌 Explicación
- **Insertar/eliminar al inicio**: siempre es O(1), porque basta con mover la referencia al primer nodo.
- **Insertar/eliminar al final en lista simple**: O(n), ya que hay que recorrer toda la lista.
- **Insertar/eliminar al final en lista doble con puntero a último**: O(1), pues se accede directamente al último nodo.
- **Inserción/eliminación en posición específica**: O(n), porque es necesario recorrer hasta la posición indicada.
